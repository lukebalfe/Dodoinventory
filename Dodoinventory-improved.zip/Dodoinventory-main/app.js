// ---- Connect to Supabase ----
const SUPABASE_URL = 'https://kzoiuhaiqscaqiezzqmu.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6b2l1aGFpcXNjYXFpZXp6cW11Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI5MjcyMzUsImV4cCI6MjA5ODUwMzIzNX0.IcI9jcedtmCOU_5YNnmACRzZm00IHPqhCiV_GzIOBg8';
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let isAdmin = false;

// ---- Shared helpers ----

function money(v) {
  if (v === null || v === undefined) return '—';
  return '$' + Number(v).toFixed(2);
}

function stockStatus(item) {
  const stock = Number(item.stock_on_hand ?? 0);
  if (stock <= 0) return 'out';
  const reorder = item.reorder_level;
  if (reorder !== null && reorder !== undefined && stock <= Number(reorder)) return 'low';
  return 'good';
}

function stockLabel(status) {
  if (status === 'out') return 'Out of stock';
  if (status === 'low') return 'Low stock';
  return '';
}

// Escape user-entered text before inserting it into innerHTML templates,
// so item/vendor names etc. can never inject markup or scripts (XSS).
function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Wraps a function so it only runs after the user stops triggering it
// for `wait` ms — used to keep search-as-you-type from re-rendering
// (or re-querying) on every single keystroke.
function debounce(fn, wait = 200) {
  let t;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function slugify(s) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

function variantLabel(item) {
  const parts = [];
  if (item.attribute1_value) parts.push(item.attribute1_value);
  if (item.attribute2_value) parts.push(item.attribute2_value);
  if (item.attribute3_value) parts.push(item.attribute3_value);
  return parts.length ? parts.join(' / ') : item.variant_name;
}

async function getOrCreateByName(table, name) {
  if (!name) return null;
  const { data: existing } = await supabaseClient.from(table).select('id').eq('name', name).maybeSingle();
  if (existing) return existing.id;
  const { data: inserted, error } = await supabaseClient.from(table).insert({ name }).select('id').single();
  if (error) throw error;
  return inserted.id;
}

// ---- Live updates ----
// Subscribes to changes on a table and runs `callback` whenever a row
// changes, so open pages stay in sync without needing a manual refresh.
function subscribeToTable(table, callback) {
  const channelName = table + '-changes-' + Math.random().toString(36).slice(2);
  return supabaseClient
    .channel(channelName)
    .on('postgres_changes', { event: '*', schema: 'public', table }, callback)
    .subscribe();
}

// ---- Auth gate (runs on every page) ----
// Each page must have: #login-screen, #app, #login-form, #login-email,
// #login-password, #login-error, #signout-btn, and a function onAppReady()
// that the page defines to render its own content once auth passes.

function initAuthGate(onAppReady) {
  const loginScreen = document.getElementById('login-screen');
  const appEl = document.getElementById('app');

  async function checkAdmin() {
    const { data: { user } } = await supabaseClient.auth.getUser();
    if (!user) { isAdmin = false; return; }
    const { data } = await supabaseClient
      .from('admins')
      .select('user_id')
      .eq('user_id', user.id)
      .maybeSingle();
    isAdmin = !!data;
    document.querySelectorAll('.admin-only').forEach(el => {
      el.style.display = isAdmin ? '' : 'none';
    });
  }

  function showApp() {
    loginScreen.style.display = 'none';
    appEl.style.display = '';
    checkAdmin().then(onAppReady);
  }

  function showLogin() {
    loginScreen.style.display = 'flex';
    appEl.style.display = 'none';
  }

  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    const errorEl = document.getElementById('login-error');
    errorEl.textContent = '';

    const { error } = await supabaseClient.auth.signInWithPassword({ email, password });
    if (error) {
      errorEl.textContent = error.message;
      return;
    }
    showApp();
  });

  document.getElementById('signout-btn').addEventListener('click', async () => {
    await supabaseClient.auth.signOut();
    showLogin();
  });

  supabaseClient.auth.getSession().then(({ data }) => {
    if (data.session) showApp();
    else showLogin();
  });

  // If the session ends while the app is open (token expired, or the user
  // signed out in another tab), drop back to the login screen instead of
  // leaving a broken app showing stale data.
  supabaseClient.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_OUT' || (event === 'TOKEN_REFRESHED' && !session)) {
      showLogin();
    }
  });
}

// ---- Nav active-link highlighting + mobile collapsible menu ----
document.addEventListener('DOMContentLoaded', () => {
  const current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === current) a.classList.add('active');
  });

  const nav = document.querySelector('.topnav');
  const navLinks = document.querySelector('.nav-links');
  if (!nav || !navLinks) return;

  const toggleBtn = document.createElement('button');
  toggleBtn.className = 'nav-toggle-btn';
  toggleBtn.setAttribute('aria-label', 'Toggle navigation menu');
  toggleBtn.innerHTML = '☰';
  toggleBtn.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    toggleBtn.innerHTML = navLinks.classList.contains('open') ? '✕' : '☰';
  });

  nav.insertBefore(toggleBtn, navLinks);

  // Collapse the menu again once a link is tapped
  navLinks.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      navLinks.classList.remove('open');
      toggleBtn.innerHTML = '☰';
    });
  });
});
